import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("cottontail")