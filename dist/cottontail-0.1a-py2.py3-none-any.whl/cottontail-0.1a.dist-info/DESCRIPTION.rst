cottontail
==========

Prototyping with RabbitMQ and various protocols (MQTT, AMQP, STOMP)


